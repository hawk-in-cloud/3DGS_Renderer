# 伪代码编写规范

## 概述

伪代码（Pseudocode）是论文中展示算法逻辑的重要形式。本文档规范伪代码的编写标准。

---

## 一、伪代码类型

### 1.1 背景知识伪代码

用于介绍已有的经典算法或理论方法。

**特点**：
- 描述成熟稳定的方法
- 侧重于原理说明
- 长度：30-80 行

**使用场景**：
- 介绍经典算法
- 解释理论基础
- 展示通用方法

### 1.2 算法实现伪代码

用于展示自己设计的算法或改进的算法。

**特点**：
- 反映实际实现逻辑
- 侧重于具体步骤
- 长度：50-150 行

**使用场景**：
- 核心算法描述
- 改进方法说明
- 实现细节展示

---

## 二、伪代码结构

### 2.1 标准结构

```python
算法: 算法名称
输入: [输入参数说明]
输出: [输出参数说明]

1. [步骤1]
2. [步骤2]
3. [步骤3]
   3.1 [子步骤]
   3.2 [子步骤]
4. [步骤4]
```

### 2.2 详细结构

```python
算法: 算法名称
输入: 
  - param1: 参数1说明
  - param2: 参数2说明
输出: 
  - result: 结果说明

变量:
  - var1: 变量1说明
  - var2: 变量2说明

1. 初始化变量
   var1 ← param1
   var2 ← 0

2. 循环处理
   for i from 1 to n do
       var2 ← var2 + var1[i]
   end for

3. 返回结果
   return var2
```

---

## 三、语法规范

### 3.1 变量赋值

```
# 赋值
x ← 5
y ← x + 1

# 数组访问
array[i] ← value

# 交换
swap(a, b)
```

### 3.2 条件语句

```
# if 语句
if condition then
    [执行语句]
else
    [执行语句]
end if

# 多条件
if condition1 then
    [执行语句]
else if condition2 then
    [执行语句]
else
    [执行语句]
end if
```

### 3.3 循环语句

```
# for 循环
for i from start to end do
    [执行语句]
end for

# while 循环
while condition do
    [执行语句]
end while

# 遍历
for each item in collection do
    [执行语句]
end for
```

### 3.4 函数调用

```
# 函数调用
result ← functionName(param1, param2)

# 递归调用
result ← recursiveFunction(param)
```

### 3.5 注释

```
# 单行注释
[执行语句]  # 注释内容
```

---

## 四、格式要求

### 4.1 缩进

- 使用 4 空格缩进
- 保持缩进一致

### 4.2 编号

- 顶级步骤使用 1, 2, 3...
- 子步骤使用 1.1, 1.2... 或 1), 2)...

### 4.3 字体

- 伪代码使用等宽字体
- 关键字可以使用粗体

---

## 五、示例

### 5.1 背景知识伪代码示例

```
算法: 快速排序
输入: 数组 A[1...n]
输出: 排序后的数组 A

1. if n ≤ 1 then
2.     return A
3. end if
4. 
5. pivot ← A[n]  # 选择最后一个元素作为基准
6. i ← 0
7. 
8. for j from 0 to n-1 do
9.     if A[j] ≤ pivot then
10.        swap(A[i], A[j])
11.        i ← i + 1
12.    end if
13. end for
14. 
15. swap(A[i], A[n])  # 将基准放到正确位置
16. 
17. # 递归排序左右两部分
18. QuickSort(A[1...i-1])
19. QuickSort(A[i+1...n])
20.
21. return A
```

### 5.2 算法实现伪代码示例

```
算法: 改进的粒子群优化算法
输入: 
  - popSize: 种群大小
  - maxIter: 最大迭代次数
  - dim: 搜索维度
输出: 最优解位置和适应度值

变量:
  - population[popSize][dim]: 粒子位置
  - velocity[popSize][dim]: 粒子速度
  - pBest[popSize][dim]: 个体最优位置
  - gBest[dim]: 全局最优位置
  - fitness[popSize]: 适应度值

1. 初始化
2.   for i from 0 to popSize-1 do
3.       for d from 0 to dim-1 do
4.           population[i][d] ← random()
5.           velocity[i][d] ← random()
6.           pBest[i][d] ← population[i][d]
7.       end for
8.       fitness[i] ← evaluate(population[i])
9.   end for
10.  gBest ← findBest(population, fitness)
11.
12. 迭代优化
13.  for iter from 0 to maxIter-1 do
14.      for i from 0 to popSize-1 do
15.          for d from 0 to dim-1 do
16.              # 更新速度（引入自适应权重）
17.              w ← adaptiveWeight(iter, maxIter)
18.              r1, r2 ← random()
19.              velocity[i][d] ← w * velocity[i][d] +
20.                               r1 * (pBest[i][d] - population[i][d]) +
21.                               r2 * (gBest[d] - population[i][d])
22.              
23.              # 更新位置
24.              population[i][d] ← population[i][d] + velocity[i][d]
25.              
26.              # 边界处理
27.              if population[i][d] out of bounds then
28.                  population[i][d] ← clamp(population[i][d])
29.              end if
30.          end for
31.
32.          # 更新适应度
33.          newFitness ← evaluate(population[i])
34.          if newFitness < fitness[i] then
35.              fitness[i] ← newFitness
36.              pBest[i] ← population[i]
37.          end if
38.      end for
39.
40.      # 更新全局最优
41.      gBest ← updateGlobalBest(population, fitness, gBest)
42.  end for
43.
44. return gBest, evaluate(gBest)
```

---

## 六、注意事项

### 6.1 清晰简洁

- 避免过于冗余
- 突出核心逻辑
- 适当使用注释

### 6.2 完整性

- 包含输入输出说明
- 包含变量定义
- 包含返回语句

### 6.3 可读性

- 使用有意义的变量名
- 适当分组相关步骤
- 使用空行分隔逻辑块

---

## 七、自检清单

- [ ] 有算法名称
- [ ] 有输入输出说明
- [ ] 变量有定义说明
- [ ] 步骤编号清晰
- [ ] 有适当注释
- [ ] 长度适中（30-150行）
- [ ] 逻辑清晰可读
