#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
参考文献格式化脚本
支持 GB/T 7714-2015 等多种格式

Usage:
    python reference_formatter.py --input refs.txt --format gb7714 --output refs.md
    python reference_formatter.py --input refs.json --format apa --output refs.md
"""

import argparse
import json
import re
import sys


FORMATS = {
    "gb7714": {
        "name": "GB/T 7714-2015",
        "journal": "{authors}. {title}[J]. {journal}, {year}, {volume}({issue}): {pages}.",
        "conference": "{authors}. {title}[C]//{conference}. {address}: {publisher}, {year}: {pages}.",
        "book": "{authors}. {title}[M]. {address}: {publisher}, {year}.",
        "thesis": "{authors}. {title}[D]. {school}, {year}.",
        "web": "{authors}. {title}[EB/OL]. ({date})[{access_date}]. {url}."
    },
    "apa": {
        "name": "APA 7th Edition",
        "journal": "{authors} ({year}). {title}. {journal}, {volume}({issue}), {pages}. https://doi:{doi}",
        "conference": "{authors} ({year}). {title}. In {conference} (Ed.), {book_title} (pp. {pages}). {publisher}.",
        "book": "{authors} ({year}). {title}. {publisher}.",
        "thesis": "{authors} ({year}). {title} [Doctor's thesis, {school}].",
        "web": "{authors} ({year}). {title}. Retrieved {access_date}, from {url}"
    },
    "ieee": {
        "name": "IEEE",
        "journal": "{authors}, \"{title},\" {journal}, vol. {volume}, no. {issue}, pp. {pages}, {year}.",
        "conference": "{authors}, \"{title},\" in {conference}, {year}, pp. {pages}.",
        "book": "{authors}, {title}. {address}: {publisher}, {year}."
    }
}


def parse_authors(authors_str):
    """解析作者列表"""
    if not authors_str:
        return []

    if "，" in authors_str or "、" in authors_str:
        if "，" in authors_str:
            authors = authors_str.split("，")
        else:
            authors = authors_str.split("、")
    elif "," in authors_str:
        authors = authors_str.split(",")
    else:
        authors = [authors_str]

    return [a.strip() for a in authors if a.strip()]


def format_authors_gb(authors):
    """格式化作者（GB格式）"""
    if not authors:
        return ""

    if len(authors) == 1:
        return authors[0]
    elif len(authors) == 2:
        return f"{authors[0]}, {authors[1]}"
    else:
        return f"{authors[0]}, et al."


def format_authors_apa(authors):
    """格式化作者（APA格式）"""
    if not authors:
        return ""

    if len(authors) == 1:
        return authors[0]
    elif len(authors) == 2:
        return f"{authors[0]} & {authors[1]}"
    elif len(authors) <= 20:
        return ", ".join(authors[:-1]) + ", & " + authors[-1]
    else:
        return ", ".join(authors[:19]) + ", ... " + authors[-1]


def format_authors_ieee(authors):
    """格式化作者（IEEE格式）"""
    if not authors:
        return ""

    if len(authors) == 1:
        return authors[0]
    elif len(authors) == 2:
        return f"{authors[0]} and {authors[1]}"
    else:
        return f"{authors[0]} et al."


def detect_type(ref):
    """检测参考文献类型"""
    if "journal" in ref or "journal_name" in ref:
        return "journal"
    elif "conference" in ref or "proceedings" in ref:
        return "conference"
    elif "school" in ref or "degree" in ref:
        return "thesis"
    elif "url" in ref or "website" in ref:
        return "web"
    else:
        return "book"


def format_reference(ref, format_type="gb7714"):
    """格式化单条参考文献"""
    if format_type not in FORMATS:
        print(f"Warning: Unknown format '{format_type}', using GB/T 7714")
        format_type = "gb7714"

    template = FORMATS[format_type]

    authors = parse_authors(ref.get("authors", ""))
    ref_type = detect_type(ref)

    if ref_type == "journal":
        fmt = template["journal"]
    elif ref_type == "conference":
        fmt = template["conference"]
    elif ref_type == "thesis":
        fmt = template["thesis"]
    elif ref_type == "web":
        fmt = template["web"]
    else:
        fmt = template["book"]

    if format_type == "gb7714":
        authors_str = format_authors_gb(authors)
    elif format_type == "apa":
        authors_str = format_authors_apa(authors)
    else:
        authors_str = format_authors_ieee(authors)

    result = fmt.format(
        authors=authors_str,
        title=ref.get("title", ""),
        journal=ref.get("journal", ref.get("journal_name", "")),
        year=ref.get("year", ""),
        volume=ref.get("volume", ""),
        issue=ref.get("issue", ref.get("number", "")),
        pages=ref.get("pages", ""),
        conference=ref.get("conference", ref.get("proceedings", "")),
        address=ref.get("address", ""),
        publisher=ref.get("publisher", ""),
        school=ref.get("school", ""),
        date=ref.get("date", ""),
        access_date=ref.get("access_date", ""),
        url=ref.get("url", ""),
        doi=ref.get("doi", "")
    )

    return result


def parse_txt(input_file):
    """解析文本格式的参考文献"""
    refs = []
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()

    lines = content.strip().split('\n')
    for line in lines:
        line = line.strip()
        if not line:
            continue

        ref = {}

        author_match = re.search(r'^(.+?)[.。]', line)
        if author_match:
            ref["authors"] = author_match.group(1).strip()

        year_match = re.search(r'[（\(](\d{4})[）\)]', line)
        if year_match:
            ref["year"] = year_match.group(1)

        if "[J]" in line:
            ref["type"] = "journal"
        elif "[C]" in line:
            ref["type"] = "conference"
        elif "[M]" in line:
            ref["type"] = "book"
        elif "[D]" in line:
            ref["type"] = "thesis"

        refs.append(ref)

    return refs


def load_json(input_file):
    """从JSON文件加载参考文献"""
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    if isinstance(data, list):
        return data
    elif isinstance(data, dict) and "references" in data:
        return data["references"]
    else:
        return [data]


def main():
    parser = argparse.ArgumentParser(description='参考文献格式化工具')
    parser.add_argument('--input', type=str, required=True, help='输入文件（支持.txt或.json）')
    parser.add_argument('--format', type=str, default='gb7714',
                        choices=['gb7714', 'apa', 'ieee'], help='输出格式')
    parser.add_argument('--output', type=str, default='refs_formatted.md', help='输出文件')

    args = parser.parse_args()

    input_file = args.input
    if input_file.endswith('.json'):
        references = load_json(input_file)
    else:
        references = parse_txt(input_file)

    formatted = []
    for i, ref in enumerate(references, 1):
        formatted_ref = format_reference(ref, args.format)
        formatted.append(f"[{i}] {formatted_ref}")

    output = "\n\n".join(formatted)

    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(output)

    print(f"格式化完成，共处理 {len(references)} 条参考文献")
    print(f"输出文件: {args.output}")


if __name__ == '__main__':
    main()
