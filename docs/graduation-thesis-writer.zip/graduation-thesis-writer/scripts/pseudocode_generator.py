#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
伪代码生成脚本
支持背景知识伪代码和算法实现伪代码生成

Usage:
    python pseudocode_generator.py --type background --input paper.txt --output pseudocode.md
    python pseudocode_generator.py --type algorithm --project-path /path/to/project --output pseudocode.md
"""

import argparse
import os
import re
import sys


def extract_algorithm_from_paper(paper_text):
    """从论文中提取算法描述"""
    algorithms = []

    algorithm_patterns = [
        r'算法\s*(\d+)?[：:]\s*(.+?)(?=算法\s*\d+[：:]|图\s*\d|参考文献|$)',
        r'Algorithm\s*(\d+)?[：:]\s*(.+?)(?=Algorithm\s*\d+[：:]|Figure\s*\d|References|$)',
        r'步骤\s*(\d+)[：:]\s*(.+?)(?=步骤\s*\d+[：:]|$)',
        r'Step\s*(\d+)[：:]\s*(.+?)(?=Step\s*\d+[：:]|$)'
    ]

    for pattern in algorithm_patterns:
        matches = re.finditer(pattern, paper_text, re.DOTALL | re.IGNORECASE)
        for match in matches:
            algorithms.append(match.group(0))

    return algorithms


def read_code_file(file_path):
    """读取代码文件"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        try:
            with open(file_path, 'r', encoding='latin-1') as f:
                return f.read()
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            return ""


def extract_functions_from_code(code):
    """从代码中提取函数定义"""
    functions = []

    patterns = [
        r'def\s+(\w+)\s*\(([^)]*)\):(.+?)(?=\ndef\s|\nclass\s|$)',
        r'function\s+(\w+)\s*\(([^)]*)\)\s*[:{](.+?)(?=\nfunction\s|\nclass\s|$)',
        r'public\s+(?:static\s+)?\w+\s+(\w+)\s*\(([^)]*)\)\s*[{](.+?)(?=^\s*public|^\s*private|$)',
        r'private\s+\w+\s+(\w+)\s*\(([^)]*)\)\s*[{](.+?)(?=^\s*public|^\s*private|$)',
    ]

    for pattern in patterns:
        matches = re.finditer(pattern, code, re.DOTALL | re.MULTILINE)
        for match in matches:
            functions.append({
                'name': match.group(1),
                'params': match.group(2),
                'body': match.group(3)
            })

    return functions


def extract_classes_from_code(code):
    """从代码中提取类定义"""
    classes = []

    patterns = [
        r'class\s+(\w+)(?:\s*\(([^)]*)\))?\s*[:{](.+?)(?=^class\s|\Z)',
        r'class\s+(\w+)\s*[:{](.+?)(?=^class\s|\Z)'
    ]

    for pattern in patterns:
        matches = re.finditer(pattern, code, re.DOTALL | re.MULTILINE)
        for match in matches:
            classes.append({
                'name': match.group(1),
                'inheritance': match.group(2) if match.lastindex >= 2 else None,
                'body': match.group(match.lastindex)
            })

    return classes


def generate_background_pseudocode(algorithm_text, max_lines=80):
    """生成背景知识伪代码"""
    lines = []
    lines.append("```")
    lines.append("算法: 背景知识算法")
    lines.append("")
    lines.append("输入: [输入参数说明]")
    lines.append("输出: [输出参数说明]")
    lines.append("")

    steps = re.findall(r'(?:步骤|Step)\s*(\d+)[：:]\s*(.+?)(?=(?:步骤|Step)\s*\d+[：:]|$)',
                       algorithm_text, re.DOTALL)

    if steps:
        for step_num, step_content in steps:
            lines.append(f"{step_num}. {step_content.strip()}")
    else:
        content_lines = algorithm_text.split('\n')
        for line in content_lines[:max_lines - 10]:
            if line.strip():
                lines.append(f"1. {line.strip()}")

    lines.append("```")

    return '\n'.join(lines)


def generate_algorithm_pseudocode(project_path, function_name=None, max_lines=150):
    """生成算法实现伪代码"""
    code_extensions = ['.py', '.java', '.cpp', '.c', '.js', '.ts', '.go', '.rs']

    all_functions = []
    all_classes = []

    for root, dirs, files in os.walk(project_path):
        dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', 'node_modules', 'venv', 'env']]

        for file in files:
            if any(file.endswith(ext) for ext in code_extensions):
                file_path = os.path.join(root, file)
                code = read_code_file(file_path)

                functions = extract_functions_from_code(code)
                for func in functions:
                    func['file'] = file
                    all_functions.append(func)

                classes = extract_classes_from_code(code)
                for cls in classes:
                    cls['file'] = file
                    all_classes.append(cls)

    if not all_functions and not all_classes:
        return "未找到可识别的代码结构"

    lines = []
    lines.append("```")
    lines.append(f"算法: {'.'.join([function_name]) if function_name else all_functions[0]['name'] if all_functions else all_classes[0]['name']}")
    lines.append("")

    if function_name:
        target_funcs = [f for f in all_functions if f['name'] == function_name]
    else:
        target_funcs = all_functions[:3]

    for func in target_funcs:
        lines.append(f"函数: {func['name']}({func['params']})")
        lines.append("")

        params = [p.strip() for p in func['params'].split(',') if p.strip()]
        if params:
            lines.append("参数:")
            for param in params:
                lines.append(f"  - {param}")
            lines.append("")

        lines.append("过程:")
        body_lines = func['body'].split('\n')[:50]
        for line in body_lines:
            stripped = line.strip()
            if stripped and not stripped.startswith('#') and not stripped.startswith('//'):
                lines.append(f"  {stripped}")

        lines.append("")
        lines.append("返回: [返回值说明]")
        lines.append("")

    if all_classes:
        lines.append("类结构:")
        for cls in all_classes[:2]:
            lines.append(f"  class {cls['name']}")
            if cls['inheritance']:
                lines.append(f"    继承: {cls['inheritance']}")

    lines.append("```")

    return '\n'.join(lines[:max_lines])


def main():
    parser = argparse.ArgumentParser(description='伪代码生成工具')
    parser.add_argument('--type', type=str, required=True,
                        choices=['background', 'algorithm'],
                        help='伪代码类型: background(背景知识) 或 algorithm(算法实现)')
    parser.add_argument('--input', type=str,
                        help='输入文件（背景知识伪代码使用）')
    parser.add_argument('--project-path', type=str,
                        help='项目路径（算法实现伪代码使用）')
    parser.add_argument('--function', type=str,
                        help='指定函数名（可选）')
    parser.add_argument('--output', type=str, default='pseudocode.md',
                        help='输出文件')
    parser.add_argument('--max-lines', type=int, default=80,
                        help='最大行数（默认80）')

    args = parser.parse_args()

    if args.type == 'background':
        if not args.input:
            print("Error: --input is required for background pseudocode")
            sys.exit(1)

        with open(args.input, 'r', encoding='utf-8') as f:
            paper_text = f.read()

        algorithms = extract_algorithm_from_paper(paper_text)

        if algorithms:
            pseudocode = generate_background_pseudocode(algorithms[0], args.max_lines)
        else:
            pseudocode = generate_background_pseudocode(paper_text, args.max_lines)

    elif args.type == 'algorithm':
        if not args.project_path:
            print("Error: --project-path is required for algorithm pseudocode")
            sys.exit(1)

        pseudocode = generate_algorithm_pseudocode(
            args.project_path,
            args.function,
            args.max_lines
        )

    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(pseudocode)

    print(f"伪代码已生成: {args.output}")
    print(f"类型: {args.type}")


if __name__ == '__main__':
    main()
