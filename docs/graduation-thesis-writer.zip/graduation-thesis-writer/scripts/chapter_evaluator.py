#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
毕业论文章节质量评估脚本
7维度评估体系，每个维度1-5分，总分35分，及格线28分

Usage:
    python chapter_evaluator.py --chapter "第1章内容"
    python chapter_evaluator.py --file chapter.md --output scores.json
"""

import argparse
import json
import re
import sys


DIMENSIONS = {
    "论文结构": {
        "weight": 5,
        "description": "章节逻辑、层次清晰",
        "keywords": ["首先", "其次", "最后", "因此", "然而", "但是"]
    },
    "内容完整": {
        "weight": 5,
        "description": "内容要点覆盖完整",
        "keywords": ["包括", "涉及", "包含", "具有", "实现"]
    },
    "学术规范": {
        "weight": 5,
        "description": "术语准确、表达规范",
        "keywords": ["定义", "概念", "理论", "方法", "研究"]
    },
    "论证深度": {
        "weight": 5,
        "description": "逻辑推导、实验分析",
        "keywords": ["因为", "所以", "表明", "说明", "验证"]
    },
    "创新表达": {
        "weight": 5,
        "description": "独特见解、合理创新",
        "keywords": ["创新", "改进", "优化", "新颖", "独特"]
    },
    "语言质量": {
        "weight": 5,
        "description": "表达流畅、符合学术规范",
        "keywords": ["本文", "本研究", "通过", "采用", "利用"]
    },
    "格式规范": {
        "weight": 5,
        "description": "引用格式、图表规范",
        "keywords": ["图", "表", "参考文献", "[1]", "如图"]
    }
}


FORBIDDEN_WORDS = [
    "总之", "综上所述", "具有", "的意义", "不仅", "还", "一方面",
    "另一方面", "致力于"
]


def check_forbidden_words(text):
    """检查禁用词汇"""
    found = []
    for word in FORBIDDEN_WORDS:
        if word in text:
            found.append(word)
    return found


def analyze_structure(text):
    """分析论文结构"""
    score = 3

    heading_pattern = r'^#{1,3}\s+'
    headings = re.findall(heading_pattern, text, re.MULTILINE)

    if len(headings) >= 3:
        score += 1

    has_intro = any(kw in text for kw in ["首先", "第一", "1.1"])
    has_body = any(kw in text for kw in ["其次", "第二", "2.1"])
    has_conclusion = any(kw in text for kw in ["最后", "第三", "总结"])

    if has_intro and has_body and has_conclusion:
        score += 1

    return min(score, 5)


def analyze_completeness(text, content_points=None):
    """分析内容完整性"""
    score = 3

    min_words = 500
    word_count = len(text)

    if word_count >= min_words:
        score += 1

    if content_points:
        covered = sum(1 for point in content_points if point.lower() in text.lower())
        coverage = covered / len(content_points)
        if coverage >= 0.7:
            score += 1

    return min(score, 5)


def analyze_academic(text):
    """分析学术规范性"""
    score = 3

    academic_terms = ["定义", "概念", "理论", "方法", "研究", "分析", "提出", "实现"]
    term_count = sum(1 for term in academic_terms if term in text)

    if term_count >= 5:
        score += 1

    sentence_count = len(re.split(r'[。！？]', text))
    if sentence_count >= 5:
        score += 1

    return min(score, 5)


def analyze_depth(text):
    """分析论证深度"""
    score = 3

    reasoning_keywords = ["因为", "所以", "因此", "表明", "说明", "通过", "实验", "结果"]
    reasoning_count = sum(1 for kw in reasoning_keywords if kw in text)

    if reasoning_count >= 3:
        score += 1

    has_analysis = any(kw in text for kw in ["分析", "讨论", "可以看出"])
    if has_analysis:
        score += 1

    return min(score, 5)


def analyze_innovation(text):
    """分析创新表达"""
    score = 3

    innovation_keywords = ["创新", "改进", "优化", "新颖", "独特", "提出", "新方法"]
    innovation_count = sum(1 for kw in innovation_keywords if kw in text)

    if innovation_count >= 2:
        score += 1

    has_comparison = any(kw in text for kw in ["对比", "比较", "优于", "不同"])
    if has_comparison:
        score += 1

    return min(score, 5)


def analyze_language(text):
    """分析语言质量"""
    score = 3

    forbidden = check_forbidden_words(text)
    if forbidden:
        score -= len(forbidden)

    academic_keywords = ["本文", "本研究", "本文所", "本文提出的"]
    if any(kw in text for kw in academic_keywords):
        score += 1

    has_variety = len(set(text.split())) / len(text.split()) > 0.3
    if has_variety:
        score += 1

    return max(1, min(score, 5))


def analyze_format(text):
    """分析格式规范"""
    score = 3

    has_figure = "图" in text
    has_table = "表" in text
    has_reference = "参考文献" in text or "[1]" in text

    if has_figure or has_table:
        score += 1
    if has_reference:
        score += 1

    return min(score, 5)


def evaluate_chapter(text, content_points=None):
    """评估章节质量"""
    scores = {
        "论文结构": analyze_structure(text),
        "内容完整": analyze_completeness(text, content_points),
        "学术规范": analyze_academic(text),
        "论证深度": analyze_depth(text),
        "创新表达": analyze_innovation(text),
        "语言质量": analyze_language(text),
        "格式规范": analyze_format(text)
    }

    total = sum(scores.values())

    passed = all(s >= 3 for s in scores.values()) and total >= 28

    return {
        "scores": scores,
        "total": total,
        "passed": passed,
        "failed_dimensions": [k for k, v in scores.items() if v < 3]
    }


def print_report(result):
    """打印评估报告"""
    print("\n" + "="*50)
    print("章节质量评估报告")
    print("="*50 + "\n")

    print("各维度评分：")
    for dimension, score in result["scores"].items():
        status = "✓" if score >= 3 else "✗"
        print(f"  {dimension}: {score}/5 {status}")

    print(f"\n总分: {result['total']}/35")

    if result["passed"]:
        print("\n✅ 及格 - 该章节符合质量要求")
    else:
        print("\n❌ 不及格 - 需要修改")
        if result["failed_dimensions"]:
            print(f"不合格维度: {', '.join(result['failed_dimensions'])}")

    print("\n" + "="*50)


def main():
    parser = argparse.ArgumentParser(description='毕业论文章节质量评估工具')
    parser.add_argument('--chapter', type=str, help='章节内容文本')
    parser.add_argument('--file', type=str, help='章节文件路径')
    parser.add_argument('--output', type=str, help='输出JSON文件路径')
    parser.add_argument('--content-points', type=str, help='内容要点（逗号分隔）')

    args = parser.parse_args()

    text = ""
    if args.chapter:
        text = args.chapter
    elif args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                text = f.read()
        except FileNotFoundError:
            print(f"Error: File not found: {args.file}")
            sys.exit(1)
    else:
        print("Error: Please provide --chapter or --file")
        sys.exit(1)

    content_points = None
    if args.content_points:
        content_points = [p.strip() for p in args.content_points.split(',')]

    result = evaluate_chapter(text, content_points)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"评估报告已保存到: {args.output}")

    print_report(result)

    sys.exit(0 if result["passed"] else 1)


if __name__ == '__main__':
    main()
